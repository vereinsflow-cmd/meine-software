import { fluesseStarten, fluss } from "./fluss.js?v=2026102001";
const bewegungAus = window.matchMedia("(prefers-reduced-motion: reduce)");
const buehneMq = window.matchMedia("(min-width: 1024px) and (min-height: 720px) and (prefers-reduced-motion: no-preference)");
const feinMq = window.matchMedia("(hover: hover) and (pointer: fine)");
const scrollZeit = CSS.supports("animation-timeline: view()");
const canObserve = "IntersectionObserver" in window;
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const px = (n) => `${Math.round(n * 100) / 100}px`;
const buehne = $("[data-buehne]");
const fahrt = $("[data-fahrt]");
const kamera = $("[data-kamera]");
const kopf = $("[data-kopf]");
const randRechts = $('[data-randlicht="rechts"]');
const randLinks = $('[data-randlicht="links"]');
function randlichter() {
if (!buehne || !randRechts || !randLinks) return;
const iphone = $(".k01 .iphone");
const seite = $(".k01 .iphone-side-r");
const front = $(".k01 .iphone-front");
if (!iphone || !seite || !front || buehne.classList.contains("ist-faehrt")) return;
const b = buehne.getBoundingClientRect();
const s = seite.getBoundingClientRect();
const f = front.getBoundingClientRect();
if (!s.height || !f.height) return;
const setzen = (el, x, top, hoehe) => {
el.style.setProperty("left", px(x - b.left - 1.25));
el.style.setProperty("top", px(top - b.top));
el.style.setProperty("height", px(hoehe));
el.classList.add("ist-an");
};
setzen(randRechts, s.right, s.top + s.height * 0.14, s.height * 0.72);
setzen(randLinks, f.left + 1, f.top + f.height * 0.12, f.height * 0.5);
}
function randlichterAus() {
randRechts?.classList.remove("ist-an");
randLinks?.classList.remove("ist-an");
}
const einstiegGeraete = $$(".k01 [data-geraet]");
function posieren(showcase) {
if (showcase.classList.contains("ist-posiert")) return;
showcase.classList.add("ist-posiert");
showcase.closest(".geraet")?.classList.add("ist-posiert");
if (showcase.dataset.geraet === "laptop") queueMicrotask(bildVorladen);
if (showcase.dataset.geraet === "handy") {
const pose = $(".pose", showcase);
const fertig = () => randlichter();
if (bewegungAus.matches) fertig();
else pose?.addEventListener("transitionend", fertig, { once: true });
}
}
for (const sc of einstiegGeraete) {
if (sc.classList.contains("is-rest")) posieren(sc);
new MutationObserver(() => {
if (sc.classList.contains("is-rest")) posieren(sc);
}).observe(sc, { attributes: true, attributeFilter: ["class"] });
}
if (bewegungAus.matches) einstiegGeraete.forEach(posieren);
const titel = $(".einstieg-titel");
function offsetIn(el, vorfahr) {
let x = 0;
let y = 0;
let e = el;
while (e && e !== vorfahr) {
x += e.offsetLeft;
y += e.offsetTop;
const p = e.offsetParent;
if (p && p !== vorfahr) {
x += p.clientLeft;
y += p.clientTop;
}
e = p;
}
return [x, y];
}
let geometrieBereit = false;
function geometrie() {
if (!buehne || !kamera) return;
if (!buehneMq.matches) {
geometrieBereit = false;
return;
}
const laptop = $(".k01 .showcase-laptop");
const bild = $(".k01 .laptop-screen picture");
if (!laptop || !bild) return;
const S = parseFloat(getComputedStyle(laptop).getPropertyValue("--sw")) || 1056;
const W = buehne.clientWidth;
const H = buehne.clientHeight;
const handy = $(".k01 .geraet-handy");
const u = (titel && parseFloat(getComputedStyle(titel).fontSize) / 104) || Math.min(window.innerWidth / 1440, H / 900);
const gx = handy ? handy.offsetLeft - (1118 - 64) * u : W / 2 - 656 * u;
const y0 = handy ? handy.offsetTop - 372 * u : H / 2 - 450 * u;
const [bx, by] = offsetIn(bild, kamera);
const set = (k, v) => buehne.style.setProperty(k, typeof v === "number" ? px(v) : v);
const ks0 = (640 * u) / S;
set("--ks0", String(Math.round(ks0 * 10000) / 10000));
set("--kx0", gx + (366 - 64) * u);
set("--ky0", y0 + 250 * u);
const oben = Math.round(Math.max(0.42 * (H - S / 1.6), 24));
const kx2 = Math.round(W / 2 - S / 2 - bx);
const ky2 = oben - Math.round(by);
set("--kx2", kx2);
set("--ky2", ky2);
const ks1 = 0.94;
const cx = kx2 + bx + S / 2;
const cy = ky2 + by + S / 3.2;
set("--ks1", String(ks1));
set("--kx1", cx - ks1 * (bx + S / 2));
set("--ky1", cy - ks1 * (by + S / 3.2));
const fs = S / W;
set("--fs", String(Math.round(fs * 100000) / 100000));
set("--fx", kx2 + bx);
set("--fy", ky2 + by - fs * (W / 44));
if (titel) {
const ox = titel.offsetWidth * 0.32;
const oy = titel.offsetHeight * 0.55;
for (const teil of $$(".w, .w-pin", titel)) {
const [x, y] = offsetIn(teil, titel);
teil.style.setProperty("--ox", px(ox - x));
teil.style.setProperty("--oy", px(oy - y));
}
}
geometrieBereit = true;
}
let grosseBilder = false;
let vorladenGeplant = false;
function bildVorladen() {
if (vorladenGeplant || grosseBilder || !buehneMq.matches || !scrollZeit) return;
vorladenGeplant = true;
if ("requestIdleCallback" in window) requestIdleCallback(bilderNachladen, { timeout: 1500 });
else setTimeout(bilderNachladen, 600);
}
function bilderNachladen() {
if (grosseBilder) return;
grosseBilder = true;
const flach = $("[data-fahrt-flach] img");
const schirm = $(".k01 .laptop-screen img");
const gross = flach?.dataset.gross;
if (!gross) return;
const einsetzen = () => {
for (const img of [schirm, flach]) {
if (!img) continue;
img.sizes = "100vw";
img.srcset = gross;
}
};
const probe = new Image();
probe.sizes = "100vw";
probe.srcset = gross;
if (probe.decode) probe.decode().then(einsetzen, einsetzen);
else probe.addEventListener("load", einsetzen, { once: true });
}
let waechterIo;
function waechterStarten() {
waechterIo?.disconnect();
if (!buehne || !canObserve) return;
buehne.classList.remove("ist-faehrt", "fahrt-1", "fahrt-2");
if (!buehneMq.matches) {
kopf?.classList.remove("ist-weg");
return;
}
const zustand = { start: true, mitte: false, ende: false, danach: false };
const anwenden = () => {
const faehrt = !zustand.start;
if (faehrt !== buehne.classList.contains("ist-faehrt")) {
buehne.classList.toggle("ist-faehrt", faehrt);
if (faehrt) randlichterAus();
else setTimeout(randlichter, 950);
}
kopf?.classList.toggle("ist-weg", zustand.ende);
if (faehrt) bilderNachladen();
if (!scrollZeit) {
buehne.classList.toggle("fahrt-1", zustand.mitte);
buehne.classList.toggle("fahrt-2", zustand.ende || zustand.danach);
}
};
waechterIo = new IntersectionObserver(
(entries) => {
for (const e of entries) {
const art = e.target.dataset.fahrtWaechter;
zustand[art] = e.isIntersecting;
if (art === "ende") zustand.danach = !e.isIntersecting && e.boundingClientRect.top < 0;
}
anwenden();
},
{ rootMargin: "0px 0px -99% 0px" },
);
$$("[data-fahrt-waechter]", fahrt).forEach((w) => waechterIo.observe(w));
}
const FAHRT_DAUER = 1800;
const SCHWELLE = 40;
const SCHWELLE_FINGER = 32;
const fahrtKurve = kurve(0.3, 0.1, 0.3, 1);
const fahrplan = (() => {
const N = 1000;
const sig = (x, b) => 1 / (1 + Math.exp(-x / b));
const dichte = (p) => 1 - 0.55 * sig(p - 0.6, 0.03) * (1 - sig(p - 0.9, 0.03)) + 6 * sig(p - 0.935, 0.012);
const tau = new Float64Array(N + 1);
for (let i = 1; i <= N; i++) tau[i] = tau[i - 1] + dichte((i - 0.5) / N);
for (let i = 1; i <= N; i++) tau[i] /= tau[N];
return {
tau(p) {
const x = Math.min(1, Math.max(0, p)) * N;
const i = Math.min(N - 1, Math.floor(x));
return tau[i] + (tau[i + 1] - tau[i]) * (x - i);
},
p(z) {
let lo = 0;
let hi = N;
while (hi - lo > 1) {
const m = (lo + hi) >> 1;
if (tau[m] < z) lo = m;
else hi = m;
}
return Math.min(1, Math.max(0, (lo + (z - tau[lo]) / (tau[hi] - tau[lo] || 1)) / N));
},
};
})();
const innen = $("[data-fahrt-innen]");
const auto = {
an: false,
ruhig: false,
geo: null,
lauf: null,
nachlauf: null,
sammel: { r: 0, px: 0, n: 0, t: 0 },
rad: { t: -1e9, d: 0 },
radSpur: [],
taste: "",
finger: null,
richtung: { r: 0, t: -1e9 },
halt: null,
raf: 0,
ruhe: 0,
radDran: false,
};
let autoIo;
let nahIo;
function strecke() {
if (!auto.geo) {
const a = fahrt.getBoundingClientRect().top + scrollY;
auto.geo = { a, e: a + Math.max(0, fahrt.offsetHeight - innerHeight) };
}
return auto.geo;
}
function lageIn(y, g) {
if (Math.abs(y - g.a) <= 2) return "anfang";
if (Math.abs(y - g.e) <= 2) return "ende";
return y > g.a && y < g.e ? "mitte" : "aussen";
}
const ganz = (y) => {
const d = window.devicePixelRatio || 1;
return Math.round(y * d) / d;
};
function plan(von, nach, v0, t0) {
const g = strecke();
const L = Math.max(1, g.e - g.a);
const r = Math.sign(nach - von) || 1;
const weg = Math.abs(nach - von) / L || 1e-4;
let dauer = FAHRT_DAUER * (0.4 + 0.6 * Math.min(1, weg));
const v = (v0 * r) / L;
if ((v * dauer) / weg > 2.7) dauer = Math.max(300, (2.7 * weg) / v);
const m = Math.max(-1, Math.min(2.7, (v * dauer) / weg));
const l = { von, nach, r, m, t0, dauer, gesetzt: von, tLetzt: t0, z0: (von - g.a) / L, z1: (nach - g.a) / L, fp: false };
if (Math.abs(m) < 0.01) {
l.m = 0;
l.fp = true;
l.z0 = fahrplan.tau(l.z0);
l.z1 = fahrplan.tau(l.z1);
l.dauer = FAHRT_DAUER * (0.4 + 0.6 * Math.min(1, Math.abs(l.z1 - l.z0)));
}
return l;
}
function planLage(l, t) {
const s = Math.min(1, Math.max(0, (t - l.t0) / l.dauer));
if (s >= 1) return l.nach;
const g = strecke();
const z = l.z0 + (l.z1 - l.z0) * (l.m ? s * s * (3 - 2 * s) + l.m * s * (1 - s) ** 2 : fahrtKurve(s));
return g.a + (l.fp ? fahrplan.p(z) : z) * (g.e - g.a);
}
const planTempo = (l, t) => {
const t1 = Math.min(Math.max(t, l.t0), l.t0 + l.dauer - 8);
return (planLage(l, t1 + 8) - planLage(l, t1)) / 8;
};
function fahren(ziel, t = performance.now(), v0) {
const l = auto.lauf;
const v = v0 ?? (l ? planTempo(l, t) : 0);
auto.sammel.px = auto.sammel.n = 0;
auto.nachlauf = null;
bilderNachladen();
const y = scrollY;
if (Math.abs(ziel - y) < 1) {
auto.lauf = null;
return;
}
auto.lauf = plan(y, ziel, v, l ? t : null);
if (!auto.raf) auto.raf = requestAnimationFrame(fahrtBild);
}
function fahrtBild(t) {
auto.raf = 0;
let l = auto.lauf;
if (!l) return;
if (l.t0 === null) l.t0 = l.tLetzt = t - 1000 / 60;
const ist = scrollY;
const ab = ist - l.gesetzt;
let schub = 0;
if (Math.abs(ab) > 2) {
if (Math.sign(ab) !== l.r || (l.nach - ist) * l.r < -2) return abbrechen(Math.sign(ab));
const v = Math.max(planTempo(l, l.tLetzt) * l.r, (ab * l.r) / Math.max(8, t - l.tLetzt));
l = auto.lauf = plan(ist, l.nach, v * l.r, l.tLetzt);
schub = ab;
}
const fertig = t >= l.t0 + l.dauer;
let y = fertig ? l.nach : planLage(l, t);
if (schub && !fertig) y = ist + l.r * Math.max(0, (y - ist) * l.r - schub * l.r);
y = fertig ? y : ganz(y);
if (Math.abs(y - ist) >= 0.25) window.scrollTo(0, y);
l.gesetzt = scrollY;
l.tLetzt = t;
if (!fertig) {
auto.raf = requestAnimationFrame(fahrtBild);
return;
}
auto.lauf = null;
auto.halt = l.nach;
auto.nachlauf = { ziel: l.nach, bis: t + 900 };
}
function abbrechen(r = 0) {
auto.lauf = null;
auto.nachlauf = null;
if (auto.raf) cancelAnimationFrame(auto.raf);
auto.raf = 0;
if (r) auto.richtung = { r, t: performance.now() };
ruheAbwarten();
}
function sofortAnsZiel() {
const l = auto.lauf;
if (!l) return;
abbrechen();
auto.geo = null;
const g = strecke();
auto.halt = l.r > 0 ? g.e : g.a;
window.scrollTo(0, auto.halt);
}
function ruheAbwarten() {
if (auto.ruhe || !auto.an || auto.lauf) return;
let y = scrollY;
let seit = performance.now();
let r = performance.now() - auto.richtung.t < 600 ? auto.richtung.r : auto.halt === null ? 0 : Math.sign(y - auto.halt);
const blick = (t) => {
auto.ruhe = 0;
if (!auto.an || auto.lauf) return;
const g = strecke();
const jetzt = scrollY;
if (lageIn(jetzt, g) !== "mitte") return;
if (Math.abs(jetzt - y) > 0.5) {
r = Math.sign(jetzt - y);
y = jetzt;
seit = t;
}
if (t - seit >= 160 && !auto.finger) {
fahren(r > 0 ? g.e : r < 0 ? g.a : jetzt - g.a < g.e - jetzt ? g.a : g.e, t, 0);
return;
}
auto.ruhe = requestAnimationFrame(blick);
};
auto.ruhe = requestAnimationFrame(blick);
}
function sammeln(r, betrag, t) {
const s = auto.sammel;
if (s.r !== r || t - s.t > 400) Object.assign(s, { r, px: 0, n: 0 });
s.t = t;
s.px += betrag;
if (betrag >= 3) s.n++;
return s.px >= SCHWELLE || s.n >= 4;
}
function rad(e) {
if (!auto.an || e.ctrlKey || Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
const dy = e.deltaY * (e.deltaMode === 1 ? 40 : e.deltaMode === 2 ? innerHeight : 1);
if (!dy) return;
const r = Math.sign(dy);
const t = performance.now();
const y = scrollY;
const vorher = auto.rad;
auto.rad = { t, d: dy };
const spur = (auto.radSpur = [...auto.radSpur.filter((p) => t - p.t <= 120), { t, y }]);
const tempo = t - spur[0].t >= 30 ? (y - spur[0].y) / (t - spur[0].t) : 0;
const l = auto.lauf;
if (l) {
if (e.cancelable) e.preventDefault();
if (r !== l.r && sammeln(r, Math.abs(dy), t)) fahren(r > 0 ? strecke().e : strecke().a, t);
return;
}
const n = auto.nachlauf;
if (n) {
const rest = t - vorher.t < 140 && Math.sign(vorher.d) === r && Math.abs(dy) <= Math.abs(vorher.d) * 1.3 + 4;
if (rest && t < n.bis && Math.abs(scrollY - n.ziel) <= 2) {
if (e.cancelable) e.preventDefault();
return;
}
auto.nachlauf = null;
}
const g = strecke();
const lage = lageIn(y, g);
if (lage === "aussen") return;
if (lage === "mitte") {
if (e.cancelable) {
e.preventDefault();
fahren(r > 0 ? g.e : g.a, t, tempo);
} else if (r > 0 ? y >= g.a + SCHWELLE : y <= g.e - SCHWELLE) fahren(r > 0 ? g.e : g.a, t, tempo || Math.max(-2, Math.min(2, dy / 16.7)));
else auto.richtung = { r, t: performance.now() };
return;
}
auto.halt = y;
if ((lage === "anfang") !== r > 0) return;
if (!e.cancelable) return;
e.preventDefault();
if (sammeln(r, Math.abs(dy), t)) fahren(r > 0 ? g.e : g.a, t, 0);
}
function radAn(an) {
if (an === auto.radDran) return;
auto.radDran = an;
if (an) window.addEventListener("wheel", rad, { passive: false });
else window.removeEventListener("wheel", rad, { passive: false });
}
const TASTEN = { ArrowDown: 1, PageDown: 1, " ": 1, ArrowUp: -1, PageUp: -1 };
function taste(e) {
if (!auto.an || e.defaultPrevented || e.altKey || e.ctrlKey || e.metaKey) return;
const ziel = e.target instanceof Element ? e.target : null;
if (ziel?.closest("input, textarea, select, [contenteditable], [role]:not([role='list'])") || (e.key === " " && ziel?.closest("button, summary"))) return;
if (e.key === "Home" || e.key === "End") {
if (auto.lauf) abbrechen();
return;
}
const r = e.key === " " && e.shiftKey ? -1 : TASTEN[e.key];
if (!r) return;
const t = performance.now();
const g = strecke();
if (auto.lauf) {
e.preventDefault();
auto.taste = e.key;
if (r !== auto.lauf.r && !e.repeat) fahren(r > 0 ? g.e : g.a, t);
return;
}
if (e.repeat && e.key === auto.taste && auto.nachlauf && Math.abs(scrollY - auto.nachlauf.ziel) <= 2) {
e.preventDefault();
return;
}
const lage = lageIn(scrollY, g);
if (lage === "mitte" || (lage === "anfang" && r > 0) || (lage === "ende" && r < 0)) {
e.preventDefault();
auto.taste = e.key;
fahren(r > 0 ? g.e : g.a, t, 0);
}
}
function fingerAuf(e) {
if (!auto.an || e.touches.length !== 1) {
auto.finger = null;
return;
}
auto.finger = { y0: e.touches[0].clientY, nativ: false, ab: Boolean(auto.lauf) };
}
function fingerZug(e) {
const f = auto.finger;
if (!f || !auto.an || e.touches.length !== 1) return;
const dy = f.y0 - e.touches[0].clientY;
const t = performance.now();
const l = auto.lauf;
if (l) {
if (e.cancelable) e.preventDefault();
f.ab = true;
if (Math.sign(dy) === -l.r && Math.abs(dy) >= SCHWELLE_FINGER * 1.5) {
f.y0 = e.touches[0].clientY;
fahren(l.r > 0 ? strecke().a : strecke().e, t);
}
return;
}
if (f.ab) {
if (e.cancelable) e.preventDefault();
return;
}
if (f.nativ) return;
const g = strecke();
const lage = lageIn(scrollY, g);
const r = lage === "anfang" ? 1 : lage === "ende" ? -1 : Math.sign(dy);
if (lage === "aussen" || dy * r < 0 || !e.cancelable) {
f.nativ = true;
return;
}
e.preventDefault();
if (Math.abs(dy) >= (lage === "mitte" ? 6 : SCHWELLE_FINGER)) {
f.ab = true;
fahren(r > 0 ? g.e : g.a, t, 0);
}
}
function fingerAb(e) {
if (!e.touches.length) auto.finger = null;
}
function autoStarten() {
autoIo?.disconnect();
nahIo?.disconnect();
if (auto.lauf) sofortAnsZiel();
if (auto.ruhe) cancelAnimationFrame(auto.ruhe);
auto.ruhe = 0;
auto.geo = null;
auto.nachlauf = null;
auto.finger = null;
const an = Boolean(fahrt && innen && canObserve && scrollZeit && buehneMq.matches && !auto.ruhig);
if (an !== auto.an) {
const art = an ? "addEventListener" : "removeEventListener";
fahrt?.[art]("touchstart", fingerAuf, { passive: true });
fahrt?.[art]("touchmove", fingerZug, { passive: false });
fahrt?.[art]("touchend", fingerAb, { passive: true });
fahrt?.[art]("touchcancel", fingerAb, { passive: true });
}
auto.an = an;
if (!an) {
radAn(false);
return;
}
nahIo = new IntersectionObserver((es) => radAn(es.at(-1).isIntersecting && auto.an));
nahIo.observe(fahrt);
autoIo = new IntersectionObserver((es) => es.at(-1).isIntersecting && ruheAbwarten(), { rootMargin: "0px 0px -99% 0px" });
autoIo.observe(innen);
const y = scrollY;
if (lageIn(y, strecke()) !== "mitte") auto.halt = lageIn(y, strecke()) === "aussen" ? null : y;
if ($(".k01 .showcase-laptop.ist-posiert")) bildVorladen();
}
window.addEventListener("keydown", taste);
window.addEventListener("keyup", (e) => {
if (e.key === auto.taste) auto.taste = "";
});
window.addEventListener("resize", () => {
if (!auto.an) return;
if (auto.lauf) return sofortAnsZiel();
const alt = auto.geo;
auto.geo = null;
if (!alt) return;
const g = strecke();
const y = scrollY;
if (Math.abs(y - alt.e) <= 2 && Math.abs(g.e - alt.e) > 0.5) window.scrollTo(0, g.e);
else if (Math.abs(y - alt.a) <= 2 && Math.abs(g.a - alt.a) > 0.5) window.scrollTo(0, g.a);
});
document.addEventListener("visibilitychange", () => {
if (document.hidden) sofortAnsZiel();
});
document.addEventListener("vf:ruhe", (e) => {
auto.ruhig = Boolean(e.detail?.ruhig);
autoStarten();
});
const walze = $("[data-walze-woerter]");
const woerter = walze ? $$(".wort", walze) : [];
const liste = $$(".wortliste li");
let wortJetzt = -1;
let wortAnimationen = [];
function buchstabenTeilen() {
for (const w of woerter) {
if (w.dataset.geteilt) continue;
w.dataset.geteilt = "1";
for (const knoten of [...w.childNodes]) {
if (knoten.nodeType !== Node.TEXT_NODE) continue;
const frag = document.createDocumentFragment();
for (const z of knoten.textContent) {
const b = document.createElement("span");
b.className = "b";
b.textContent = z;
frag.append(b);
}
knoten.replaceWith(frag);
}
}
}
function wortSetzen(n, animiert = true) {
if (n === wortJetzt || !woerter.length) return;
const vorher = wortJetzt;
wortJetzt = n;
wortAnimationen.forEach((a) => a.finish());
wortAnimationen = [];
woerter.forEach((w, i) => {
w.classList.toggle("ist-jetzt", i === n);
w.classList.toggle("ist-vor1", i === n - 1);
w.classList.toggle("ist-vor2", i === n - 2);
w.classList.toggle("ist-weg", i < n - 2);
});
liste.forEach((li, i) => {
li.classList.toggle("vorbei", i < n);
li.classList.toggle("jetzt", i === n);
});
if (!animiert || bewegungAus.matches || !buehneMq.matches) return;
const alt = woerter[vorher];
if (alt?.animate) {
wortAnimationen.push(alt.animate([{ filter: "blur(0)" }, { filter: "blur(3px)", offset: 0.4 }, { filter: "blur(0)" }], { duration: 450, easing: "ease-out" }));
}
const neu = woerter[n];
if (neu && n > vorher) {
$$(".b", neu).forEach((b, i) => {
wortAnimationen.push(
b.animate(
[
{ transform: "translateY(0.42em)", opacity: 0, filter: "blur(3px)" },
{ transform: "translateY(0)", opacity: 1, filter: "blur(0)" },
],
{ duration: 420, delay: i * 30, easing: "cubic-bezier(0.23, 1, 0.32, 1)", fill: "backwards" },
),
);
});
}
}
function walzeEinpassen() {
if (!walze) return;
walze.style.removeProperty("--wg");
if (!buehneMq.matches) return;
const fs = parseFloat(getComputedStyle(walze).fontSize);
const verfuegbar = walze.clientWidth;
let breit = 0;
for (const w of woerter) breit = Math.max(breit, w.scrollWidth);
if (breit > verfuegbar && breit > 0) walze.style.setProperty("--wg", px(Math.floor(fs * (verfuegbar / breit) * 0.985)));
}
let zonenIo;
function walzeStarten() {
if (!walze) return;
zonenIo?.disconnect();
if (!buehneMq.matches || !canObserve) {
woerter.forEach((w) => w.classList.remove("ist-jetzt", "ist-vor1", "ist-vor2", "ist-weg"));
wortJetzt = -1;
return;
}
buchstabenTeilen();
walzeEinpassen();
if (wortJetzt < 0) wortSetzen(0, false);
zonenIo = new IntersectionObserver(
(entries) => {
for (const e of entries) if (e.isIntersecting) wortSetzen(Number(e.target.dataset.zone));
},
{ rootMargin: "-45% 0px -54% 0px" },
);
$$(".walze-zone").forEach((z) => zonenIo.observe(z));
}
const magnete = $$(".magnet").map((el) => ({ el, kreis: $(".kreis", el), x: 0, y: 0, vx: 0, vy: 0, tx: 0, ty: 0, sichtbar: false }));
let zeiger = null;
let magnetSchleife = 0;
const MAGNET_WEITE = 140;
const MAGNET_ZUG = 13;
function magnetBild() {
magnetSchleife = 0;
let weiter = false;
for (const m of magnete) {
if (!m.sichtbar && !m.x && !m.y && !m.vx && !m.vy) continue;
m.tx = 0;
m.ty = 0;
let nah = false;
if (zeiger && m.sichtbar) {
const r = m.el.getBoundingClientRect();
const cx = r.left - m.x + r.width / 2;
const cy = r.top - m.y + r.height / 2;
const dx = zeiger.x - cx;
const dy = zeiger.y - cy;
const ausX = Math.max(0, Math.abs(dx) - r.width / 2);
const ausY = Math.max(0, Math.abs(dy) - r.height / 2);
const aussen = Math.hypot(ausX, ausY);
if (aussen < MAGNET_WEITE) {
nah = true;
const d = Math.hypot(dx, dy) || 1;
const kraft = MAGNET_ZUG * Math.min(1, d / 90) * (1 - (aussen / MAGNET_WEITE) ** 2);
m.tx = (dx / d) * kraft;
m.ty = (dy / d) * kraft * 0.75;
}
}
m.el.classList.toggle("ist-nah", nah);
m.vx = (m.vx + (m.tx - m.x) * 0.14) * 0.74;
m.vy = (m.vy + (m.ty - m.y) * 0.14) * 0.74;
m.x += m.vx;
m.y += m.vy;
if (Math.abs(m.tx - m.x) < 0.05 && Math.abs(m.ty - m.y) < 0.05 && Math.abs(m.vx) < 0.05 && Math.abs(m.vy) < 0.05) {
m.x = m.tx;
m.y = m.ty;
m.vx = 0;
m.vy = 0;
} else weiter = true;
if (m.x || m.y) {
m.el.style.setProperty("translate", `${m.x.toFixed(2)}px ${m.y.toFixed(2)}px`);
m.kreis?.style.setProperty("translate", `${(m.x * 0.5).toFixed(2)}px ${(m.y * 0.5).toFixed(2)}px`);
} else {
m.el.style.removeProperty("translate");
m.kreis?.style.removeProperty("translate");
}
if (nah) weiter = true;
}
if (weiter) magnetSchleife = requestAnimationFrame(magnetBild);
}
function magnetStarten() {
if (!magnetSchleife) magnetSchleife = requestAnimationFrame(magnetBild);
}
if (magnete.length) {
if (canObserve) {
const io = new IntersectionObserver((entries) => {
for (const e of entries) {
const m = magnete.find((x) => x.el === e.target);
if (m) m.sichtbar = e.isIntersecting;
}
});
magnete.forEach((m) => io.observe(m.el));
}
window.addEventListener(
"pointermove",
(e) => {
if (e.pointerType !== "mouse" || !feinMq.matches || bewegungAus.matches) return;
zeiger = { x: e.clientX, y: e.clientY };
if (magnete.some((m) => m.sichtbar)) magnetStarten();
},
{ passive: true },
);
document.documentElement.addEventListener("pointerleave", () => {
zeiger = null;
magnetStarten();
});
}
const ROLL = "cubic-bezier(0.16, 1, 0.3, 1)";
function kurve(x1, y1, x2, y2) {
const b = (a1, a2, t) => 3 * a1 * t * (1 - t) ** 2 + 3 * a2 * t * t * (1 - t) + t ** 3;
return (x) => {
let t = x;
for (let i = 0; i < 8; i++) {
const d = (b(x1, x2, t + 1e-4) - b(x1, x2, t)) / 1e-4;
if (!d) break;
t = Math.min(1, Math.max(0, t - (b(x1, x2, t) - x) / d));
}
return b(y1, y2, t);
};
}
const rollKurve = kurve(0.16, 1, 0.3, 1);
const neuEl = (tag, cls, text) => {
const e = document.createElement(tag);
if (cls) e.className = cls;
if (text !== undefined) e.textContent = text;
return e;
};
function zaehlwerk(el, von, zyklen) {
if (!el || el.dataset.zw) return null;
el.dataset.zw = "1";
const text = el.textContent;
const rollen = [];
el.textContent = "";
[...text].forEach((z, pos) => {
if (!/\d/.test(z)) return el.append(z);
const folge = von[pos] === " " ? [" ", z] : [];
if (!folge.length) {
let d = Number(von[pos]);
folge.push(d);
for (let k = ((Number(z) - d + 10) % 10) + 10 * (zyklen[rollen.length] || 0); k > 0; k--) folge.push((d = (d + 1) % 10));
}
const r = neuEl("span", "zw-r");
for (const f of folge) r.append(neuEl("span", "", f === " " ? "\u00a0" : String(f)));
const s = neuEl("span", "zw-s");
s.append(neuEl("span", "zw-platz", z), r);
el.append(s);
rollen.push({ r, s, schritte: folge.length - 1, oben: `translateY(${(((folge.length - 1) / folge.length) * 100).toFixed(4)}%)` });
});
rollen.el = el;
return rollen;
}
const zwAnfang = (rs) => rs?.forEach(({ r, oben }) => r.style.setProperty("transform", oben));
const zwEnde = (rs) =>
rs?.forEach(({ r, s }) => {
r.getAnimations().forEach((a) => a.cancel());
s.getAnimations().forEach((a) => a.cancel());
r.style.removeProperty("transform");
s.classList.remove("zw-weich");
});
function zwHoch(rs, dauer) {
zwEnde(rs);
if (!rs?.length) return;
const fs = parseFloat(getComputedStyle(rs.el).fontSize) || 40;
rs.forEach(({ r, s, oben, schritte }, i) => {
const d = dauer * (0.42 + 0.58 * ((i + 1) / rs.length) ** 1.4);
r.animate([{ transform: oben }, { transform: "translateY(0)" }], { duration: d, easing: ROLL, fill: "backwards" });
if (!schritte) return;
const b = Math.min(5, fs * 0.03);
const maske = [];
const blur = [];
for (let k = 0; k <= 24; k++) {
const rest = schritte * (1 - rollKurve(k / 24));
maske.push({ "--zw-f": `${Math.min(0.32, rest * 1.2).toFixed(3)}em`, offset: k / 24 });
blur.push({ filter: `blur(${(b * Math.min(1, rest / 2)).toFixed(2)}px)`, offset: k / 24 });
}
r.animate(blur, { duration: d, easing: "linear" });
s.classList.add("zw-weich");
s.animate(maske, { duration: d, easing: "linear" }).finished.then(
() => s.classList.remove("zw-weich"),
() => {},
);
});
}
function zwRunter(rs, dauer) {
rs?.forEach(({ r, oben }) => {
r.getAnimations().forEach((a) => a.cancel());
r.style.setProperty("transform", oben);
r.animate([{ transform: "translateY(0)" }, { transform: oben }], { duration: dauer, easing: ROLL });
});
}
function zaehlenBeimErscheinen(el, von, zyklen, dauer) {
if (!el || !canObserve || bewegungAus.matches) return;
const rs = zaehlwerk(el, von, zyklen);
const huelle = el.closest(".gz-zahl") ?? el;
zwAnfang(rs);
huelle.classList.add("zw-wartet");
const io = new IntersectionObserver(
([e]) => {
if (!e.isIntersecting) return;
io.disconnect();
huelle.classList.remove("zw-wartet");
zwHoch(rs, dauer);
},
{ threshold: 0.6 },
);
io.observe(el);
}
zaehlenBeimErscheinen($(".dreizehn [data-zahl]"), " 0", [0, 1], 1300);
zaehlenBeimErscheinen($(".geldzahl [data-zahl]"), " 0.000,00", [0, 0, 0, 0, 0, 1, 1], 1500);
const spur = $("[data-spur]");
const spurMq = window.matchMedia("(min-width: 1200px) and (min-height: 760px) and (prefers-reduced-motion: no-preference)");
const spurFlug = $(".fluss-flug");
let spurSchritt = -1;
let spurZahl = null;
let eingetragen = false;
let flugNr = 0;
let spurIo;
function eintragen(animiert) {
eingetragen = true;
const nr = ++flugNr;
if (animiert) zwHoch(spurZahl, 1500);
else zwEnde(spurZahl);
const landen = () => {
if (nr !== flugNr || spurSchritt < 2) return;
spur.classList.add("ist-eingetragen");
if (!animiert) return;
spur.classList.remove("ist-gelandet");
void spur.offsetWidth;
spur.classList.add("ist-gelandet");
};
const f = animiert && spurFlug && fluss(spurFlug);
if (f) Promise.race([f.flug($("#platz-anna"), { dauer: 1200 }), new Promise((r) => setTimeout(r, 1800))]).then(landen);
else landen();
}
function spurSetzen(n) {
if (n === spurSchritt) return;
const sprung = spurSchritt < 0 || Math.abs(n - spurSchritt) > 1;
spurSchritt = n;
if (sprung) {
spur.classList.add("sofort");
requestAnimationFrame(() => requestAnimationFrame(() => spur.classList.remove("sofort")));
}
spur.dataset.schritt = String(n);
if (n >= 2 && !eingetragen) eintragen(!sprung);
else if (n < 2 && eingetragen) {
eingetragen = false;
flugNr++;
spur.classList.remove("ist-eingetragen", "ist-gelandet");
if (sprung) zwAnfang(spurZahl);
else zwRunter(spurZahl, 420);
}
}
function spurStarten() {
if (!spur) return;
spurIo?.disconnect();
if (!spurMq.matches || !canObserve) {
delete spur.dataset.schritt;
spur.classList.remove("ist-eingetragen", "ist-gelandet");
zwEnde(spurZahl);
spurSchritt = -1;
eingetragen = false;
return;
}
spurZahl ??= zaehlwerk($(".k03 [data-zahl]"), " 0", [0, 1]);
if (spurSchritt < 0) {
zwAnfang(spurZahl);
spurSetzen(0);
}
spurIo = new IntersectionObserver(
(entries) => {
for (const e of entries) {
const n = Number(e.target.dataset.schritt);
if (e.isIntersecting) spurSetzen(n);
else if (n === 1 && e.boundingClientRect.top > window.innerHeight * 0.45) spurSetzen(0);
}
},
{ rootMargin: "-45% 0px -54% 0px" },
);
$$(".spur-zone", spur).forEach((z) => spurIo.observe(z));
}
const k03Ampel = spur && $(".ampel-glas", spur);
let fuellIo;
function fuellenKompakt() {
fuellIo?.disconnect();
if (!k03Ampel || spurMq.matches || !canObserve || bewegungAus.matches || spur.classList.contains("ist-gefuellt")) return;
spurZahl ??= zaehlwerk($(".k03 [data-zahl]"), " 0", [0, 1]);
zwAnfang(spurZahl);
spur.classList.add("fuellt");
fuellIo = new IntersectionObserver(
([e]) => {
if (!e.isIntersecting) return;
fuellIo.disconnect();
spur.classList.add("ist-gefuellt");
zwHoch(spurZahl, 1500);
},
{ threshold: 0.6 },
);
fuellIo.observe(k03Ampel);
}
const kreis = $("[data-kreisbahn]");
const kreisShow = kreis && $(".showcase", kreis);
const kreisGeraet = kreis && $(".showcase-scene > *", kreis);
const kreisChips = kreis ? $$(".u-chip", kreis) : [];
const kreisMq = window.matchMedia("(min-width: 1200px) and (min-height: 720px)");
const kreisPause = { hover: false, weg: false, ruhe: false };
let kreisAnim = [];
let kreisW = 0;
function kreisMessen() {
if (!kreisGeraet) return false;
const [x, y] = offsetIn(kreisGeraet, kreis);
const w = kreisGeraet.offsetWidth;
const h = kreisGeraet.offsetHeight;
if (!w || !h) return false;
const k = Math.max(0.6, Math.min(1, (kreis.clientWidth - x - w / 2 - 150) / (1.12 * w)));
kreisW = w * k;
for (const [n, v] of [["--uk", String(Math.round(k * 1000) / 1000)], ["--ux", px(x + w / 2)], ["--uy", px(y + h / 2)], ["--uw", px(w)], ["--uh", px(h)]]) kreis.style.setProperty(n, v);
return true;
}
function kreisForm(th) {
const ex = 1.02 * kreisW * Math.cos(th);
const ey = 0.56 * kreisW * Math.sin(th);
const v = (Math.sin(th) + 1) / 2;
return {
transform: `translate(${(ex * 0.985 + ey * 0.1736).toFixed(1)}px, ${(ey * 0.985 - ex * 0.1736).toFixed(1)}px) translate(-50%, -50%) scale(${(0.8 + 0.34 * v ** 1.4).toFixed(3)})`,
zIndex: v >= 0.5 ? 3 : -1,
opacity: (0.5 + 0.5 * v).toFixed(3),
filter: `blur(${((1 - v) * 2.4).toFixed(2)}px)`,
};
}
const kreisAnhalten = () => kreisAnim.forEach((a) => (kreisPause.hover || kreisPause.weg || kreisPause.ruhe ? a.pause() : a.play()));
function kreisStarten() {
const phase = kreisAnim[0]?.currentTime ?? 0;
kreisAnim.forEach((a) => a.cancel());
kreisAnim = [];
if (!kreis) return;
const an = kreisMq.matches && kreisMessen();
kreis.style.removeProperty("--chips-h");
if (an) {
kreis.classList.remove("ist-umlauf");
const ohne = kreis.offsetHeight;
kreis.classList.add("ist-umlauf");
const mit = kreis.offsetHeight;
if (ohne > mit) kreis.style.setProperty("--chips-h", px(ohne - mit));
}
kreis.classList.toggle("ist-umlauf", Boolean(an));
const still = bewegungAus.matches || !document.body.animate;
if (an && (still || kreisShow?.classList.contains("is-rest"))) kreis.classList.add("ist-kreist");
kreisChips.forEach((li, i) => {
const chip = $(".chip", li);
for (const [e, p] of [[li, "transform"], [li, "z-index"], [chip, "opacity"], [chip, "filter"]]) e?.style.removeProperty(p);
if (!an) return;
const th0 = Math.PI / 2 + ((i - 4) * 2 * Math.PI) / 5;
if (still) {
const f = kreisForm(th0);
li.style.setProperty("transform", f.transform);
li.style.setProperty("z-index", String(f.zIndex));
chip?.style.setProperty("opacity", f.opacity);
chip?.style.setProperty("filter", f.filter);
return;
}
const formen = Array.from({ length: 61 }, (_, k) => kreisForm(th0 + (k / 60) * 2 * Math.PI));
const opt = { duration: 40000, iterations: Infinity };
kreisAnim.push(
li.animate(formen.map(({ transform }) => ({ transform })), opt),
li.animate(formen.map(({ zIndex }) => ({ zIndex })), opt),
);
if (chip) kreisAnim.push(chip.animate(formen.map(({ opacity, filter }) => ({ opacity, filter })), opt));
});
const zeit = document.timeline?.currentTime ?? 0;
kreisAnim.forEach((a) => (a.startTime = zeit - phase));
kreisAnhalten();
}
if (kreis) {
if (kreisShow) {
new MutationObserver(() => kreisShow.classList.contains("is-rest") && kreis.classList.add("ist-kreist")).observe(kreisShow, { attributes: true, attributeFilter: ["class"] });
}
for (const li of kreisChips) {
for (const [typ, an] of [["pointerenter", true], ["pointerleave", false]]) {
li.addEventListener(typ, () => {
kreisPause.hover = an;
kreisAnhalten();
});
}
}
if (canObserve) {
new IntersectionObserver(([e]) => {
kreisPause.weg = !e.isIntersecting;
kreisAnhalten();
}).observe(kreis);
}
document.addEventListener("vf:ruhe", (e) => {
kreisPause.ruhe = Boolean(e.detail?.ruhig);
kreisAnhalten();
});
kreisMq.addEventListener("change", kreisStarten);
}
const apps = $("[data-apps]");
if (apps) {
const loesen = (ausser) => $$(".app.ist-aktiv", apps).forEach((a) => a !== ausser && a.classList.remove("ist-aktiv"));
apps.addEventListener("click", (e) => {
const app = e.target instanceof Element ? e.target.closest(".app-knopf")?.closest(".app") : null;
if (!app) return;
loesen(app);
app.classList.toggle("ist-aktiv");
});
document.addEventListener("click", (e) => {
if (!(e.target instanceof Node) || !apps.contains(e.target)) loesen();
});
apps.addEventListener("keydown", (e) => {
if (e.key === "Escape") loesen();
});
}
const finanz = $(".k06");
const streif = $("[data-streif]");
const finanzShow = finanz && $(".showcase", finanz);
let streifFertig = false;
let streifSichtbar = false;
function streifMessen() {
const bild = finanz && $(".laptop-screen picture", finanz);
if (!bild || !streif || bewegungAus.matches || !bild.offsetWidth) return;
const [x, y] = offsetIn(bild, streif.parentElement);
const w = bild.offsetWidth;
const h = bild.offsetHeight;
for (const [n, v] of [["--st-x", x + 0.117 * w], ["--st-y", y + 0.344 * h], ["--st-b", 0.531 * w], ["--st-h", 0.656 * h], ["--st-r", 0.02 * w]]) finanz.style.setProperty(n, px(v));
finanz.classList.add("ist-gemessen");
}
function streifZiehen() {
const band = streif && $("i", streif);
if (streifFertig || !streifSichtbar || !finanzShow?.classList.contains("is-rest") || !band?.animate) return;
streifFertig = true;
band.animate(
[
{ transform: "translateX(-140%) skewX(-14deg)", opacity: 0 },
{ opacity: 1, offset: 0.15 },
{ opacity: 1, offset: 0.8 },
{ transform: "translateX(620%) skewX(-14deg)", opacity: 0 },
],
{ duration: 1200, delay: 250, easing: "cubic-bezier(0.45, 0, 0.25, 1)" },
);
}
const finanzSzene = finanzShow && $(".showcase-scene", finanzShow);
if (finanzSzene && canObserve && !bewegungAus.matches) {
const io = new IntersectionObserver(
([e]) => {
if (!e.isIntersecting) return;
io.disconnect();
finanzShow.classList.add("is-playing");
},
{ threshold: 0.2 },
);
io.observe(finanzSzene);
}
if (streif && finanzShow && canObserve) {
new MutationObserver(streifZiehen).observe(finanzShow, { attributes: true, attributeFilter: ["class"] });
new IntersectionObserver(
([e]) => {
streifSichtbar = e.isIntersecting;
streifZiehen();
},
{ threshold: 0.6 },
).observe(streif);
}
const vorbereitet = (el) => Boolean(el && canObserve && !bewegungAus.matches && document.body.animate);
function einmalSichtbar(el, anteil, fn, rand = "0px") {
const io = new IntersectionObserver(
([e]) => {
if (!e.isIntersecting || (e.intersectionRatio < anteil - 0.001 && e.intersectionRect.height < window.innerHeight * 0.5)) return;
io.disconnect();
fn();
},
{ threshold: [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1], rootMargin: `0px 0px ${rand} 0px` },
);
io.observe(el);
}
const ruhigJetzt = () => bewegungAus.matches || document.documentElement.classList.contains("ist-ruhig");
const RAST = CSS.supports("transition-timing-function", "linear(0, 1)") ? getComputedStyle(document.documentElement).getPropertyValue("--feder-rast").trim() : "";
const EASE = "cubic-bezier(0.23, 1, 0.32, 1)";
const rollen = $("[data-rollen]");
if (vorbereitet(rollen)) {
rollen.classList.add("ist-bereit");
einmalSichtbar(rollen, 0.4, () => rollen.classList.add("ist-gelegt"));
}
const startweg = $("[data-startweg]");
if (vorbereitet(startweg)) {
const punkte = $$(".startlinie li", startweg);
const nadel = $(".sw-pin", startweg);
const fuellung = $(".sw-fuellung", startweg);
const spur = $(".sw-spur", startweg);
const fertig = () => {
punkte.forEach((li) => li.classList.add("ist-erreicht"));
startweg.classList.add("ist-gefahren");
};
startweg.classList.add("ist-bereit");
einmalSichtbar(startweg, 0.5, () => {
if (ruhigJetzt() || punkte.length !== 3 || !spur) return fertig();
const senkrecht = window.matchMedia("(max-width: 719px)").matches;
const lage = punkte.map((li) => {
const nr = $(".nr", li);
const [x, y] = offsetIn(nr, startweg);
return senkrecht ? y + nr.offsetHeight / 2 : x + nr.offsetWidth / 2;
});
const [sx, sy] = offsetIn(spur, startweg);
const laenge = senkrecht ? spur.offsetHeight : spur.offsetWidth;
const anteil = lage.map((p) => Math.max(0, Math.min(1, (p - (senkrecht ? sy : sx)) / (laenge || 1))));
const sk = (a) => (senkrecht ? `scaleY(${a.toFixed(4)})` : `scaleX(${a.toFixed(4)})`);
const T = 1400;
const zug = fuellung.animate(
[
{ transform: sk(0), offset: 0 },
{ transform: sk(anteil[0]), offset: 250 / 1800 },
{ transform: sk(anteil[0]), offset: 400 / 1800, easing: EASE },
{ transform: sk(anteil[1]), offset: 800 / 1800 },
{ transform: sk(anteil[1]), offset: 1000 / 1800, easing: EASE },
{ transform: sk(anteil[2]), offset: T / 1800, easing: EASE },
{ transform: sk(1) },
],
{ duration: 1800, fill: "forwards" },
);
if (!senkrecht && nadel) {
const d = lage.map((x) => x - lage[2]);
const rast = RAST || EASE;
nadel.animate(
[
{ transform: `translate(${d[0]}px, -10px)`, opacity: 0, easing: EASE },
{ transform: `translate(${d[0]}px, 0)`, opacity: 1, offset: 250 / T },
{ transform: `translate(${d[0]}px, 0)`, opacity: 1, offset: 400 / T, easing: rast },
{ transform: `translate(${d[1]}px, 0)`, opacity: 1, offset: 800 / T },
{ transform: `translate(${d[1]}px, 0)`, opacity: 1, offset: 1000 / T, easing: rast },
{ transform: "translate(0, 0)", opacity: 1 },
],
{ duration: T, fill: "forwards" },
);
}
[250, 800, T].forEach((t, i) => setTimeout(() => punkte[i].classList.add("ist-erreicht"), t));
zug.finished.then(
() => {
fertig();
startweg.getAnimations({ subtree: true }).forEach((a) => a.cancel());
},
() => {},
);
});
}
const vtGut = typeof document.startViewTransition === "function" && CSS.supports("interpolate-size: allow-keywords");
let uebergang = null;
function aufklappen(d) {
const fragen = d.closest(".faq") ? $$("details", d.closest(".faq")) : [];
const danach = fragen.slice(fragen.indexOf(d) + 1);
const antwort = $(".answer, .checks", d);
if (vtGut) {
uebergang?.skipTransition();
const namen = [[kopf, "vt-kopf"], [antwort, "vt-antwort"], ...danach.map((f, i) => [f, `vt-frage-${i + 1}`])];
const setzen = (an) => {
for (const [el, name] of namen) {
if (!el) continue;
if (an) el.style.setProperty("view-transition-name", name);
else el.style.removeProperty("view-transition-name");
}
};
setzen(true);
uebergang = document.startViewTransition(() => {
d.open = !d.open;
});
uebergang.finished.finally(() => {
setzen(false);
uebergang = null;
});
return;
}
const vorher = danach.map((f) => f.getBoundingClientRect().top);
d.open = !d.open;
danach.forEach((f, i) => {
const dy = vorher[i] - f.getBoundingClientRect().top;
if (Math.abs(dy) > 0.5) f.animate([{ transform: `translateY(${dy.toFixed(1)}px)` }, { transform: "none" }], { duration: 320, easing: EASE });
});
if (d.open && antwort) antwort.animate([{ opacity: 0, transform: "translateY(-8px)" }, { opacity: 1, transform: "none" }], { duration: 320, easing: EASE });
}
if (document.body.animate) {
document.documentElement.classList.add("js-klappen");
for (const d of $$(".faq details, details.mehr")) {
$("summary", d)?.addEventListener("click", (e) => {
if (bewegungAus.matches) return;
e.preventDefault();
aufklappen(d);
});
}
}
const finale = $("[data-finale]");
if (vorbereitet(finale)) {
finale.classList.add("ist-bereit");
einmalSichtbar($(".leuchtet", finale) ?? finale, 1, async () => {
const strom = $(".fluss-finale", finale);
const linien = $(".fluss-weiter", finale);
const f1 = strom && fluss(strom);
const f2 = linien && fluss(linien);
const warte = (p, ms) => Promise.race([p ?? Promise.resolve(), new Promise((r) => setTimeout(r, ms))]);
if (ruhigJetzt()) {
f1?.sammeln(0);
f2?.wachsen(0);
finale.classList.add("ist-angekommen");
return;
}
await warte(f1?.sammeln(1500), 2000);
finale.classList.add("ist-gesammelt");
await warte(f2?.wachsen(900), 1400);
finale.classList.add("ist-angekommen");
}, "-12%");
}
function bogenSprung(ziel) {
const bogen = ziel?.closest(".bogen");
if (!bogen) return;
bogen.style.setProperty("animation", "none");
requestAnimationFrame(() => requestAnimationFrame(() => bogen.style.removeProperty("animation")));
}
const zielVon = (hash) => {
try {
return hash.length > 1 ? document.getElementById(decodeURIComponent(hash.slice(1))) : null;
} catch {
return null;
}
};
document.addEventListener(
"click",
(e) => {
if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
const a = e.target instanceof Element ? e.target.closest("a[href*='#']") : null;
if (!a || a.origin !== location.origin || a.pathname !== location.pathname) return;
bogenSprung(zielVon(a.hash));
},
true,
);
if (location.hash && zielVon(location.hash)?.closest(".bogen")) {
window.addEventListener(
"load",
() => {
const ziel = zielVon(location.hash);
if (!ziel) return;
bogenSprung(ziel);
ziel.scrollIntoView({ block: "start" });
},
{ once: true },
);
}
window.addEventListener("beforeprint", () => {
rollen?.classList.add("ist-gelegt");
startweg?.classList.add("ist-gefahren");
$$(".startlinie li").forEach((li) => li.classList.add("ist-erreicht"));
finale?.classList.add("ist-angekommen");
});
function alles() {
geometrie();
waechterStarten();
autoStarten();
walzeStarten();
spurStarten();
fuellenKompakt();
kreisStarten();
streifMessen();
}
spurMq.addEventListener("change", () => {
spurStarten();
fuellenKompakt();
});
alles();
fluesseStarten();
let neuT = 0;
const neu = () => {
clearTimeout(neuT);
randlichterAus();
neuT = setTimeout(() => {
geometrie();
walzeEinpassen();
if (!buehne?.classList.contains("ist-faehrt")) randlichter();
kreisStarten();
streifMessen();
}, 160);
};
window.addEventListener("resize", neu);
buehneMq.addEventListener("change", alles);
bewegungAus.addEventListener("change", alles);
document.fonts?.ready.then(() => {
geometrie();
walzeEinpassen();
});
