(() => {
const root = document.documentElement;
const strecken = [...document.querySelectorAll("[data-explosion], [data-telefon]")];
if (!strecken.length) return;
const weniger = window.matchMedia("(prefers-reduced-motion: reduce)");
const breit = window.matchMedia("(min-width: 900px)");
const sd = Boolean(window.CSS && CSS.supports && CSS.supports("(animation-timeline: view()) and (animation-range: contain 0% contain 100%)"));
const DAUER = 1000;
const an = () => !weniger.matches && !root.classList.contains("ist-ruhig");
const buehnen = [...document.querySelectorAll("[data-explosion], [data-aussage], [data-telefon], .metall")].map((el) => ({
el,
pin: el.matches("[data-explosion]") ? () => true : el.matches("[data-telefon]") ? () => breit.matches : () => false,
oben: 0,
hoch: 0,
buehne: 0,
anims: [],
p: -1,
nah: false,
}));
const zuStrecke = new Map(buehnen.map((b) => [b.el, b]));
let aktiv = an();
let kopf = 52;
let fenster = window.innerHeight;
let letzteY = window.scrollY;
const messen = () => {
kopf = parseFloat(getComputedStyle(root).getPropertyValue("--kopf-h")) || 52;
fenster = window.innerHeight;
const y = window.scrollY;
for (const b of buehnen) {
const r = b.el.getBoundingClientRect();
b.oben = r.top + y;
b.hoch = r.height;
b.buehne = strecken.includes(b.el) ? b.el.firstElementChild.getBoundingClientRect().height : b.hoch;
b.p = -1;
b.anims = aktiv && !sd ? b.el.getAnimations({ subtree: true }).filter((a) => "animationName" in a) : [];
}
letzteY = y;
};
const fortschritt = (b, y) => {
let a;
let e;
if (b.pin()) {
a = b.oben - kopf;
e = b.oben + b.hoch - fenster;
if (b.hoch < fenster - kopf) [a, e] = [e, a];
} else {
a = b.oben - fenster;
e = b.oben + b.hoch - kopf;
}
return e > a ? Math.min(1, Math.max(0, (y - a) / (e - a))) : 1;
};
let geplant = 0;
const zeichnen = () => {
geplant = 0;
if (!aktiv || sd) return;
const y = window.scrollY;
for (const b of buehnen) {
if (!b.nah) continue;
const p = fortschritt(b, y);
if (Math.abs(p - b.p) < 0.0002) continue;
b.p = p;
for (const a of b.anims) a.currentTime = p * DAUER;
}
};
const anfordern = () => {
if (!geplant && aktiv && !sd) geplant = window.requestAnimationFrame(zeichnen);
};
const dekodiert = new WeakSet();
const dekodieren = (el) => {
for (const img of el.querySelectorAll("img")) {
if (dekodiert.has(img) || !img.decode) continue;
dekodiert.add(img);
img.decode().catch(() => {});
}
};
if ("IntersectionObserver" in window) {
const io = new IntersectionObserver(
(eintraege) => {
for (const e of eintraege) {
const b = zuStrecke.get(e.target);
b.nah = e.isIntersecting;
b.p = -1;
b.el.classList.toggle("ist-nah", b.nah);
if (b.nah && aktiv) dekodieren(b.el);
}
anfordern();
},
{ rootMargin: "50% 0px 50% 0px" },
);
for (const b of buehnen) io.observe(b.el);
} else {
for (const b of buehnen) b.nah = true;
}
const abbilden = (y, alt) => {
const d = y + kopf;
let i = -1;
alt.forEach((a, k) => {
if (a.oben <= d) i = k;
});
if (i < 0) return y;
const a = alt[i];
const n = zuStrecke.get(strecken[i]);
const o = d - a.oben;
if (o >= a.hoch) return n.oben + n.hoch + (o - a.hoch) - kopf;
const inBuehne = Math.min(Math.max(0, o - (a.hoch - a.buehne)), n.buehne);
return n.oben + (n.hoch - n.buehne) + inBuehne - kopf;
};
const umschalten = () => {
const jetzt = an();
if (jetzt === aktiv) return;
const alt = strecken.map((el) => {
const b = zuStrecke.get(el);
return { oben: b.oben, hoch: b.hoch, buehne: b.buehne };
});
const y = letzteY;
aktiv = jetzt;
messen();
const ziel = Math.max(0, Math.round(abbilden(y, alt)));
if (Math.abs(ziel - window.scrollY) >= 1) window.scrollTo(0, ziel);
letzteY = window.scrollY;
if (aktiv) {
for (const b of buehnen) if (b.nah) dekodieren(b.el);
zeichnen();
}
};
document.addEventListener("vf:ruhe", umschalten);
if (weniger.addEventListener) weniger.addEventListener("change", umschalten);
else if (weniger.addListener) weniger.addListener(umschalten);
window.addEventListener(
"scroll",
() => {
letzteY = window.scrollY;
anfordern();
},
{ passive: true },
);
let messenGeplant = 0;
const spaeterMessen = () => {
if (messenGeplant) return;
messenGeplant = window.requestAnimationFrame(() => {
messenGeplant = 0;
messen();
anfordern();
});
};
window.addEventListener("resize", spaeterMessen);
window.addEventListener("orientationchange", spaeterMessen);
window.addEventListener("pageshow", spaeterMessen);
if ("ResizeObserver" in window) {
new ResizeObserver(() => {
messen();
anfordern();
}).observe(document.body);
}
messen();
if (aktiv) dekodieren(strecken[0]);
zeichnen();
})();
