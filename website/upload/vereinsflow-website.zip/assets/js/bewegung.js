(() => {
const root = document.documentElement;
const strecken = [...document.querySelectorAll("[data-explosion], [data-telefon]")];
if (!strecken.length) return;
const weniger = window.matchMedia("(prefers-reduced-motion: reduce)");
const breit = window.matchMedia("(min-width: 900px)");
const sd = Boolean(window.CSS && CSS.supports && CSS.supports("(animation-timeline: view()) and (animation-range: contain 0% contain 100%)"));
const DAUER = 1000;
const an = () => !weniger.matches && !root.classList.contains("ist-ruhig");
const cssAnimationen = (el) => (el && el.getAnimations ? el.getAnimations({ subtree: true }).filter((a) => "animationName" in a) : []);
const buehnen = [...document.querySelectorAll("[data-explosion], [data-aussage], [data-telefon], .metall")].map((el) => ({
el,
zeit: el.matches("[data-explosion]"),
pin: el.matches("[data-explosion]") ? () => true : el.matches("[data-telefon]") ? () => breit.matches : () => false,
oben: 0,
hoch: 0,
buehne: 0,
anims: [],
p: -1,
nah: false,
}));
const zuStrecke = new Map(buehnen.map((b) => [b.el, b]));
let aktiv = an();
let kopf = 52;
let fenster = window.innerHeight;
let letzteY = window.scrollY;
const messen = () => {
kopf = parseFloat(getComputedStyle(root).getPropertyValue("--kopf-h")) || 52;
fenster = window.innerHeight;
const y = window.scrollY;
for (const b of buehnen) {
const r = b.el.getBoundingClientRect();
b.oben = r.top + y;
b.hoch = r.height;
b.buehne = strecken.includes(b.el) ? b.el.firstElementChild.getBoundingClientRect().height : b.hoch;
b.p = -1;
b.anims = aktiv && !sd && !b.zeit ? cssAnimationen(b.el) : [];
}
letzteY = y;
};
const fortschritt = (b, y) => {
let a;
let e;
if (b.pin()) {
a = b.oben - kopf;
e = b.oben + b.hoch - fenster;
if (b.hoch < fenster - kopf) [a, e] = [e, a];
} else {
a = b.oben - fenster;
e = b.oben + b.hoch - kopf;
}
return e > a ? Math.min(1, Math.max(0, (y - a) / (e - a))) : 1;
};
let geplant = 0;
const zeichnen = () => {
geplant = 0;
if (!aktiv || sd) return;
const y = window.scrollY;
for (const b of buehnen) {
if (!b.nah || b.zeit) continue;
const p = fortschritt(b, y);
if (Math.abs(p - b.p) < 0.0002) continue;
b.p = p;
for (const a of b.anims) a.currentTime = p * DAUER;
}
};
const anfordern = () => {
if (!geplant && aktiv && !sd) geplant = window.requestAnimationFrame(zeichnen);
};
const ex = buehnen.find((b) => b.zeit);
const AB = 20;
const OBEN = 4;
let exAnims = [];
let exZiel = 0;
let exLaufen = false;
let frei = false;
const freigeben = () => {
frei = true;
};
for (const typ of ["wheel", "touchstart", "keydown", "pointerdown"]) window.addEventListener(typ, freigeben, { capture: true, passive: true, once: true });
const exDauer = (a) => (a.effect ? a.effect.getComputedTiming().endTime : 0);
const rueckwaerts = (a) => Boolean(a.effect) && a.effect.getTiming().direction === "reverse";
const exRichtung = (a, rueck) => {
if (a.effect && rueckwaerts(a) !== rueck) a.effect.updateTiming({ direction: rueck ? "reverse" : "normal" });
};
const exStand = (a, jetzt) => {
const d = exDauer(a);
const laeuft = a.playState === "running" && a.startTime !== null;
const t = Math.min(d, Math.max(0, laeuft ? (jetzt - a.startTime) * a.playbackRate : (a.currentTime ?? 0)));
return rueckwaerts(a) ? d - t : t;
};
const exHolen = () => {
if (!aktiv || !ex) {
exAnims = [];
return;
}
const vorher = new Set(exAnims);
const ref = exAnims.find((a) => a.playState !== "idle");
exAnims = cssAnimationen(ex.el);
for (const a of exAnims) {
if (vorher.has(a)) continue;
if (ref && ref.playState === "running" && ref.startTime !== null) {
exRichtung(a, rueckwaerts(ref));
a.playbackRate = 1;
a.startTime = ref.startTime;
} else {
const stand = ref ? exStand(ref, performance.now()) : exZiel ? exDauer(a) : 0;
a.pause();
exRichtung(a, false);
a.currentTime = Math.min(exDauer(a), stand);
}
}
};
const exAnwenden = () => {
exHolen();
const jetzt = performance.now();
const rueck = !exZiel;
for (const a of exAnims) {
const d = exDauer(a);
if (!exLaufen) {
a.pause();
exRichtung(a, false);
a.currentTime = exZiel ? d : 0;
continue;
}
if (a.playState === "running" && a.startTime !== null && rueckwaerts(a) === rueck) continue;
const stand = exStand(a, jetzt);
if (exZiel ? stand >= d : stand <= 0) continue;
exRichtung(a, rueck);
a.playbackRate = 1;
a.startTime = jetzt - (rueck ? d - stand : stand);
}
exRuhe();
};
let ruheUhr = 0;
const exRuhe = () => {
window.clearTimeout(ruheUhr);
ruheUhr = 0;
if (!ex) return;
if (!aktiv || exZiel) {
ex.el.classList.remove("ist-zerlegt");
return;
}
const jetzt = performance.now();
const rest = exAnims.reduce((m, a) => Math.max(m, exStand(a, jetzt)), 0);
if (rest <= 0) ex.el.classList.add("ist-zerlegt");
else ruheUhr = window.setTimeout(exRuhe, rest + 40);
};
const exPruefen = () => {
if (!aktiv || !ex) return;
const y = window.scrollY;
const ziel = y > AB ? 1 : y < OBEN ? 0 : exZiel;
if (ziel === exZiel) return;
exZiel = ziel;
exLaufen = frei && y + kopf < ex.oben + ex.hoch;
exAnwenden();
};
const sprungUnten = () => {
let id = "";
try {
id = decodeURIComponent(window.location.hash.slice(1));
} catch {
return false;
}
const ziel = id ? document.getElementById(id) : null;
return Boolean(ziel) && ziel.getBoundingClientRect().top + window.scrollY - kopf - 16 > AB;
};
const exStart = (mitSprung) => {
exZiel = window.scrollY > AB || (mitSprung && sprungUnten()) ? 1 : 0;
exLaufen = false;
exAnims = [];
exAnwenden();
};
const nachLaden = () =>
window.setTimeout(() => {
freigeben();
exHolen();
}, 300);
if (document.readyState === "complete") nachLaden();
else window.addEventListener("load", nachLaden, { once: true });
if (breit.addEventListener) breit.addEventListener("change", exHolen);
else if (breit.addListener) breit.addListener(exHolen);
const dekodiert = new WeakSet();
const dekodieren = (el) => {
for (const img of el.querySelectorAll("img")) {
if (dekodiert.has(img) || !img.decode) continue;
dekodiert.add(img);
img.decode().catch(() => {});
}
};
if ("IntersectionObserver" in window) {
const io = new IntersectionObserver(
(eintraege) => {
for (const e of eintraege) {
const b = zuStrecke.get(e.target);
b.nah = e.isIntersecting;
b.p = -1;
b.el.classList.toggle("ist-nah", b.nah);
if (b.nah && aktiv) dekodieren(b.el);
}
anfordern();
},
{ rootMargin: "50% 0px 50% 0px" },
);
for (const b of buehnen) io.observe(b.el);
} else {
for (const b of buehnen) b.nah = true;
}
const abbilden = (y, alt) => {
const d = y + kopf;
let i = -1;
alt.forEach((a, k) => {
if (a.oben <= d) i = k;
});
if (i < 0) return y;
const a = alt[i];
const n = zuStrecke.get(strecken[i]);
const o = d - a.oben;
if (o >= a.hoch) return n.oben + n.hoch + (o - a.hoch) - kopf;
const inBuehne = Math.min(Math.max(0, o - (a.hoch - a.buehne)), n.buehne);
return n.oben + (n.hoch - n.buehne) + inBuehne - kopf;
};
const umschalten = () => {
const jetzt = an();
if (jetzt === aktiv) return;
const alt = strecken.map((el) => {
const b = zuStrecke.get(el);
return { oben: b.oben, hoch: b.hoch, buehne: b.buehne };
});
const y = letzteY;
aktiv = jetzt;
messen();
const ziel = Math.max(0, Math.round(abbilden(y, alt)));
if (Math.abs(ziel - window.scrollY) >= 1) window.scrollTo(0, ziel);
letzteY = window.scrollY;
exStart(false);
if (aktiv) {
for (const b of buehnen) if (b.nah) dekodieren(b.el);
zeichnen();
}
};
document.addEventListener("vf:ruhe", umschalten);
if (weniger.addEventListener) weniger.addEventListener("change", umschalten);
else if (weniger.addListener) weniger.addListener(umschalten);
window.addEventListener(
"scroll",
() => {
letzteY = window.scrollY;
exPruefen();
anfordern();
},
{ passive: true },
);
let messenGeplant = 0;
const spaeterMessen = () => {
if (messenGeplant) return;
messenGeplant = window.requestAnimationFrame(() => {
messenGeplant = 0;
messen();
anfordern();
});
};
window.addEventListener("resize", spaeterMessen);
window.addEventListener("orientationchange", spaeterMessen);
window.addEventListener("pageshow", spaeterMessen);
window.addEventListener("afterprint", () => exStart(false));
if ("ResizeObserver" in window) {
new ResizeObserver(() => {
messen();
anfordern();
}).observe(document.body);
}
messen();
exStart(true);
if (aktiv && ex) dekodieren(ex.el);
zeichnen();
})();
